import{StampedFloat64Words}from'./stampedWordTransport.js';
export const CELLS_WORD_OPTIONS=Object.freeze({wordCount:9,slots:32,prefix:'distortionCells'});
export function validateCellsDrive(v){if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>30)throw Error('Literal-cell drive requires finite0..30');return v;}
export function validateCellsAmount(v){if(typeof v!=='number'||!Number.isFinite(v)||!Number.isFinite(Math.fround(v))||!Number.isFinite(Math.fround(1-v)))throw Error('Literal-cell amount/dry requires finite Float32');return v;}
export function validateCellsPreset(p){if(!p||typeof p!=='object'||Array.isArray(p))throw Error('Complete literal-cell preset required');validateCellsDrive(p.drive);validateCellsAmount(p.amount);return p;}
export class DistortionCellsWordCodec{
 constructor(){this.f64=new StampedFloat64Words();this.words=new Uint16Array(9);this.kind=0;this.value=0;this.seconds=0;}
 encode(kind,value,seconds){if(![0,1,2].includes(kind)||typeof seconds!=='number'||!Number.isFinite(seconds)||seconds<0)throw Error('Invalid literal-cell control schema');if(kind===2)validateCellsDrive(value);else if(typeof value!=='number'||!Number.isFinite(value)||!Number.isFinite(Math.fround(value)))throw Error('Invalid literal-cell gain');this.words[0]=kind;this.f64.encode(value,this.words,1);this.f64.encode(seconds,this.words,5);return this.words;}
 decode(words,offset=0){if(!Number.isInteger(offset)||offset<0||offset+9>words.length)throw Error('Invalid literal-cell word offset');const kind=words[offset],value=this.f64.decode(words,offset+1),seconds=this.f64.decode(words,offset+5);this.encode(kind,value,seconds);this.kind=kind;this.value=value;this.seconds=seconds;return this;}
 apply(core,author){if(this.seconds!==author/core.rate)throw Error('Literal-cell authored seconds differ');core.enqueue(this.kind,this.value,author);}
 initial(core,author){if(this.seconds!==author/core.rate)throw Error('Literal-cell constructor seconds differ');core.initial(this.kind,this.value,author);}
}
