//! Live-only constructor chronology fork; generated from immutable accepted1efb.
//! Render/math identities and every allowed edit are checked by the builder.
include!(env!("CALMBGM_MODULATION_LIVE_SOURCE"));
