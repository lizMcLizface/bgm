import fs from'node:fs';import path from'node:path';import crypto from'node:crypto';
export const MODULATION_LIVE_PREDECESSOR=Object.freeze({version:'1efb0cfc290f1e11',base:'synth-engine/instrument-modulation/src/lib.rs',sha256:'8a4b329e7aabfec430e3375c3cd865e2bb84503366240edfe285090c35147dcc'});
const read=p=>fs.readFileSync(p,'utf8').replaceAll('\r\n','\n'),sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const replace=(s,a,b)=>{if(s.split(a).length!==2)throw Error('Live constructor fork anchor differs: '+a.slice(0,80));return s.replace(a,b);};
function method(s,name){const a=s.indexOf(' fn '+name+'(');if(a<0)throw Error('Missing accepted method '+name);const open=s.indexOf('{',a);let n=1,b=open+1;for(;b<s.length&&n;b++){if(s[b]==='{')n++;else if(s[b]==='}')n--;}if(n)throw Error('Unclosed accepted method');return s.slice(a,b);}
export function generateInstrumentModulationLiveSource(){
 const base=read(MODULATION_LIVE_PREDECESSOR.base);if(sha(base)!==MODULATION_LIVE_PREDECESSOR.sha256)throw Error('Accepted1efb modulation body changed');
 let source=base;const edits=[];const edit=(from,to,label)=>{source=replace(source,from,to);edits.push({from,to,label});};
 edit('peak:f64,planned:usize}','peak:f64,planned:usize,live_starts:[Option<f64>;3],live_ctor_open:bool}','dedicated live constructor state');
 edit('peak:0.,planned}))','peak:0.,planned,live_starts:[None;3],live_ctor_open:true}))','constructor state initializers');
 const prepare=method(base,'prepare'),bare=' fn prepare(&mut self,origin:f64,seconds:f64)->bool{let Some(at)=frame(origin)else{return self.reject();};if self.ready||seconds!=origin/self.rate{return self.reject();}self.ready=true;self.origin=at;self.frame=at;self.start_seconds=seconds;self.live_starts=[None;3];self.live_ctor_open=true;true}';
 edit(prepare,bare,'bare preparation: Native intrinsics, no phantom constructor events');
 edit('let start=self.start_seconds*self.rate;','let start=self.live_starts[index].expect("validated live start epoch")*self.rate;','only per-voice start-time lookup');
 edit('if !self.ready||self.frame>MAX-128||channels','if !self.ready||self.live_ctor_open||self.frame>MAX-128||channels','pre-DSP constructor publication guard');
 const methods='\n fn live_start(&mut self,voice:usize,seconds:f64)->bool{let f=(seconds*self.rate).round();if !self.ready||!self.live_ctor_open||self.calls!=0||voice>=if self.mode==0{3}else{1}||self.live_starts[voice].is_some()||!seconds.is_finite()||frame(f).is_none()||seconds!=f/self.rate||seconds<self.origin as f64/self.rate||seconds>MAX as f64/self.rate{return self.reject();}if voice>0&&self.live_starts[voice-1].is_none_or(|v|seconds<v){return self.reject();}self.live_starts[voice]=Some(seconds);true}\n fn live_seal(&mut self)->bool{let count=if self.mode==0{3}else{1};if !self.ready||!self.live_ctor_open||self.calls!=0||self.commands!=if self.mode==0{17}else{19}||self.live_starts[..count].iter().any(Option::is_none){return self.reject();}self.live_ctor_open=false;true}\n';
 edit('\n}\nimpl Drop for Engine',methods+'\n}\nimpl Drop for Engine','single-assignment epoch and complete-constructor admission');
 const bodyProof={};for(const name of['render','lfo','gain','command','sync','reset']){let actual=method(source,name);for(const e of edits.slice().reverse())if(actual.includes(e.to))actual=actual.replace(e.to,e.from);bodyProof[name]={sha256:sha(method(base,name)),unchangedAfterDeclaredAdmissionOrEpochLookup:actual===method(base,name)};if(!bodyProof[name].unchangedAfterDeclaredAdmissionOrEpochLookup)throw Error('Unapproved numerical body delta: '+name);}
 let restored=source;for(const e of edits.slice().reverse())restored=replace(restored,e.to,e.from);if(restored!==base)throw Error('Live fork contains an undeclared accepted-source delta');
 const file=(relative)=>JSON.stringify(path.resolve(relative).replaceAll('\\','/')),imports=[
 ['#[path="../../fdn-room-live/src/timeline.rs"]','#[path='+file('synth-engine/fdn-room-live/src/timeline.rs')+']'],
 ['#[path="../../rack-native-normal/src/oscillator.rs"]','#[path='+file('synth-engine/rack-native-normal/src/oscillator.rs')+']'],
 ['mod delay;mod allpass;','#[path='+file('synth-engine/instrument-modulation/src/delay.rs')+']mod delay;#[path='+file('synth-engine/instrument-modulation/src/allpass.rs')+']mod allpass;'],
 ['#[cfg(feature="allocation-audit")]mod allocation;','#[cfg(feature="allocation-audit")]#[path='+file('synth-engine/instrument-modulation-live/src/allocation.rs')+']mod allocation;']];
 for(const[a,b]of imports)source=replace(source,a,b);
 source=source.replaceAll('instrument_modulation_','instrument_modulation_live_').replace(/^\/\/!/gm,'//');
 source+='\n#[no_mangle]pub extern "C" fn instrument_modulation_live_start(p:&mut Engine,voice:u32,seconds:f64)->u32{p.live_start(voice as usize,seconds)as u32}\n#[no_mangle]pub extern "C" fn instrument_modulation_live_seal_ctor(p:&mut Engine)->u32{p.live_seal()as u32}\n#[no_mangle]pub extern "C" fn instrument_modulation_live_ctor_open(p:&Engine)->u32{p.live_ctor_open as u32}\n#[no_mangle]pub extern "C" fn instrument_modulation_live_start_epoch(p:&Engine,voice:u32)->f64{p.live_starts.get(voice as usize).copied().flatten().unwrap_or(f64::NAN)}\n';
 return{source,proof:{predecessor:MODULATION_LIVE_PREDECESSOR,wholeBaseRestoresExactly:true,allowedEdits:edits.map(e=>e.label),bodies:bodyProof,delayAllpassAndSineSourceUnchanged:true,scope:'Only bare constructor admission and explicit per-voice start-time lookup. No accepted1efb write or mathematical-operation change.'}};
}
